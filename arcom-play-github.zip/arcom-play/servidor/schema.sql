-- Arcom Play · estrutura do banco (PostgreSQL / Supabase)
-- Rode este arquivo uma vez no banco novo. Ele cria as tabelas e as funções protegidas que o app usa.
-- Ninguém acessa as tabelas diretamente: só pelas funções abaixo (segurança por RLS sem políticas).

create extension if not exists pgcrypto with schema extensions;

create table if not exists public.ap_items(code text primary key, kind text not null, data jsonb not null, updated_at timestamptz not null default now());
create table if not exists public.ap_attempts(id text primary key, code text not null, data jsonb not null, created_at timestamptz not null default now());
create index if not exists ap_attempts_code_idx on public.ap_attempts(code);
create index if not exists ap_attempts_created_idx on public.ap_attempts(created_at);
create table if not exists public.ap_secret(id int primary key, hash text not null);
create table if not exists public.ap_backup(id int primary key, data jsonb not null, updated_at timestamptz not null default now());
alter table public.ap_items enable row level security;
alter table public.ap_attempts enable row level security;
alter table public.ap_secret enable row level security;
alter table public.ap_backup enable row level security;

-- Senha do marketing: o banco guarda só uma "impressão digital" dela.
-- Troque USUARIO e SENHA (o usuário em minúsculas) e rode a linha abaixo:
-- insert into public.ap_secret(id,hash) values(1, encode(extensions.digest(encode(extensions.digest('arcomplay-admin|USUARIO|SENHA','sha256'),'hex'),'sha256'),'hex'))
--   on conflict(id) do update set hash=excluded.hash;

create or replace function public.ap_is_admin(p_key text) returns boolean language sql stable security definer set search_path=public,extensions as $$
  select exists(select 1 from public.ap_secret where id=1 and hash=encode(extensions.digest(coalesce(p_key,''),'sha256'),'hex'))
$$;
create or replace function public.ap_check(p_key text) returns boolean language sql stable security definer set search_path=public,extensions as $$
  select public.ap_is_admin(p_key)
$$;
create or replace function public.ap_publish(p_key text,p_code text,p_kind text,p_data jsonb) returns boolean language plpgsql security definer set search_path=public,extensions as $$
begin
  if not public.ap_is_admin(p_key) then raise exception 'sem permissao'; end if;
  if p_code !~ '^[a-z0-9]{4,12}$' then raise exception 'codigo invalido'; end if;
  if p_kind not in ('teste','formulario','treino') then raise exception 'tipo invalido'; end if;
  if pg_column_size(p_data) > 400000 then raise exception 'grande demais'; end if;
  insert into public.ap_items(code,kind,data,updated_at) values(p_code,p_kind,p_data,now())
  on conflict(code) do update set kind=excluded.kind,data=excluded.data,updated_at=now();
  return true;
end $$;
create or replace function public.ap_get(p_code text) returns jsonb language sql stable security definer set search_path=public as $$
  select jsonb_build_object('kind',kind,'data',data) from public.ap_items where code=p_code
$$;
create or replace function public.ap_submit(p_code text,p_id text,p_data jsonb) returns boolean language plpgsql security definer set search_path=public as $$
begin
  if not exists(select 1 from public.ap_items where code=p_code) then return false; end if;
  if pg_column_size(p_data) > 100000 then return false; end if;
  if p_id !~ '^[A-Za-z0-9_-]{4,40}$' then return false; end if;
  insert into public.ap_attempts(id,code,data) values(p_id,p_code,p_data) on conflict(id) do nothing;
  return true;
end $$;
create or replace function public.ap_pull(p_key text,p_since timestamptz default null) returns jsonb language plpgsql stable security definer set search_path=public,extensions as $$
begin
  if not public.ap_is_admin(p_key) then raise exception 'sem permissao'; end if;
  return coalesce((select jsonb_agg(jsonb_build_object('code',code,'data',data,'at',created_at) order by created_at) from public.ap_attempts where p_since is null or created_at>p_since),'[]'::jsonb);
end $$;
create or replace function public.ap_backup_put(p_key text,p_data jsonb) returns timestamptz language plpgsql security definer set search_path=public,extensions as $$
declare t timestamptz := now();
begin
  if not public.ap_is_admin(p_key) then raise exception 'sem permissao'; end if;
  if pg_column_size(p_data) > 20000000 then raise exception 'grande demais'; end if;
  insert into public.ap_backup(id,data,updated_at) values(1,p_data,t) on conflict(id) do update set data=excluded.data,updated_at=t;
  return t;
end $$;
create or replace function public.ap_backup_get(p_key text) returns jsonb language plpgsql stable security definer set search_path=public,extensions as $$
begin
  if not public.ap_is_admin(p_key) then raise exception 'sem permissao'; end if;
  return (select jsonb_build_object('data',data,'at',updated_at) from public.ap_backup where id=1);
end $$;

revoke all on function public.ap_is_admin(text) from public, anon, authenticated;
grant execute on function public.ap_check(text), public.ap_publish(text,text,text,jsonb), public.ap_get(text), public.ap_submit(text,text,jsonb), public.ap_pull(text,timestamptz), public.ap_backup_put(text,jsonb), public.ap_backup_get(text) to anon, authenticated;
-- Observação: não existe função para apagar dados. Os dados ficam guardados sem prazo.
