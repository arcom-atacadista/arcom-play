# Arcom Play

Plataforma interna do Arcom para treinar e engajar o time: **Power Quiz** (ao vivo), **Desafio Pro** (teste por link), **Responde +** (opinião por link) e **Arena Vendas** (treino de atendimento no balcão e por ligação, com clientes simulados).

## O que tem aqui

| Arquivo | Para que serve |
| --- | --- |
| `index.html` | O app inteiro, num arquivo só (telas, imagens e vozes gravadas dos clientes). |
| `arcom-config.example.js` | Modelo da configuração do banco de dados. |
| `servidor/schema.sql` | Estrutura do banco (tabelas e funções protegidas), para criar o banco do zero. |
| `_headers` | Regras do site, usadas se ele for hospedado no Cloudflare Pages. |

## Como abrir

- **No computador:** baixe o `index.html` e abra com dois cliques (Edge ou Chrome). Sem banco, os dados ficam só naquele navegador.
- **Login:** usuário do marketing e senha definidos pelo time (a senha não fica escrita no código, só uma "impressão digital" dela).

## Banco de dados (respostas que voltam e ficam guardadas)

1. Crie um projeto Supabase (ou use o Lovable Cloud) e rode `servidor/schema.sql`.
2. Cadastre a senha do marketing com a linha comentada no início do arquivo.
3. Copie `arcom-config.example.js` para `arcom-config.js`, ao lado do `index.html`, e preencha a URL e a chave **publicável**.

Com o banco ligado:
- o link e o QR ficam curtos e abrem em qualquer celular;
- as respostas do Desafio Pro, do Responde + e dos treinos voltam para Resultados;
- tudo o que o marketing cria ganha uma cópia automática no servidor;
- o Power Quiz ao vivo funciona com celulares de verdade.

**Não existe função para apagar dados no servidor.** Para guardar por muitos anos, baixe a **cópia de segurança** (tela Usuários → "Baixar cópia de segurança") pelo menos uma vez por ano e guarde no Drive do marketing.

## Hospedar (opcional)

O app é um site estático: basta publicar a pasta em qualquer hospedagem (por exemplo, Cloudflare Pages ligado a este repositório). O arquivo `arcom-config.js` precisa estar na mesma pasta do `index.html`.

## Identidade visual

Segue o Arcom Design System: verde-escuro `#1F4033`, verde-arcom `#007840`, verde-lima `#BAE64F`, fonte Red Hat Display. A empresa é sempre "o Arcom".
