// Configuração do banco de dados (Supabase / Lovable Cloud).
// Para ligar o app a um banco: copie este arquivo para "arcom-config.js",
// na mesma pasta do index.html, e preencha com a URL do projeto e a chave PUBLICÁVEL (nunca a chave secreta).
// Sem este arquivo, o app funciona sem servidor: os dados ficam só no navegador de cada pessoa.
window.ARCOM_CFG = { u: "https://SEU-PROJETO.supabase.co", k: "SUA-CHAVE-PUBLICAVEL" };
